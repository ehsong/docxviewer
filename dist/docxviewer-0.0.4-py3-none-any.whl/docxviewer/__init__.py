# docviewer
# Copyright 2018-2019 Eunhou Esther Song
# See LICENSE for details.
"""
docxviewer

"""

__version__ = '0.0.0'
__author__ = 'Eunhou Esther Song'
__license__ = 'MIT'
